<div class="notification is-danger is-light is-flex is-align-items-center" id="msg">
  <button class="delete" onclick="hideMsg()"></button>
  Data was not restored !!
</div>
