<div class="notification is-success is-light is-flex is-align-items-center" id="msg">
  <button class="delete" onclick="hideMsg()"></button>
  Data has been deleted successfully
</div>
