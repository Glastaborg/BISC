<div class="notification is-danger is-light is-flex is-align-items-center" id="msg">
  <button class="delete" onclick="hideMsg()"></button>
  New Password details was not updated !!
</div>
