<div class="notification is-success is-light is-flex is-align-items-center" id="msg">
  <button class="delete" onclick="hideMsg()"></button>
  Comment has been added successfully
</div>
