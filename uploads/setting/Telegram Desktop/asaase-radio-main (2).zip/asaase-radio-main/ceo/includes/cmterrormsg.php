<div class="notification is-danger is-light is-flex is-align-items-center" id="msg">
  <button class="delete" onclick="hideMsg()"></button>
  Comment was not added!!
</div>
