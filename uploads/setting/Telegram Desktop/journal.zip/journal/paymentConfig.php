<?php
$secretKey = "sk_test_7eb86f93d8fffa24806f2534a05f0b8f2a9fc42b"; 
$privateKey = "pk_test_a47eec5c63a5ce2a9d88c86316ec87181eb6437e";