<th {{ $attributes->merge(['scope' => 'col', 'class' => 'px-6 py-[16px] whitespace-nowrap font-semibold']) }}>
    {{ $slot }}
</th>
