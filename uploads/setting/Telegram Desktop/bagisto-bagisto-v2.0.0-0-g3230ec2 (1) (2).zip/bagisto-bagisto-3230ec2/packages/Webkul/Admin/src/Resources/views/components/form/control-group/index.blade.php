<div {{ $attributes->merge(['class' => 'mb-[10px]']) }}>
    {{ $slot }}
</div>
