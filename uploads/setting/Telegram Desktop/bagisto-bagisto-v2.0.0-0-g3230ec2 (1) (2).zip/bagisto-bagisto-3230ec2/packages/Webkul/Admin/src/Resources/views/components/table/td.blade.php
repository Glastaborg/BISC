<td {{ $attributes->merge(['scope' => 'row', 'class' => 'px-6 py-[16px] whitespace-nowrap text-gray-600']) }}>
    {{ $slot }}
</td>
