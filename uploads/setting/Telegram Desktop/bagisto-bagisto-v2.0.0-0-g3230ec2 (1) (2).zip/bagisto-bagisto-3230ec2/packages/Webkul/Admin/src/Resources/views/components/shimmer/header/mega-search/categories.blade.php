@for ($i = 0; $i < 3; $i++)
    <div class="p-[16px] border-b-[1px] dark:border-gray-800">
        <p class="shimmer w-[150px] h-[17px]"></p>
    </div>
@endfor